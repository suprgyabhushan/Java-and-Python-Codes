from calendar import *

# Examples (To be commented out)
# Call to getWeekDay
print "Today is " + string_of_weekday(getWeekDay((30, September, 2014))) + "."
# Call to nextDate
print "Tomorrow is " + string_of_date(nextDate((30, September, 2014))) + "."

# Implement your code below this line.
