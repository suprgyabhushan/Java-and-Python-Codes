#!/usr/bin/python

import string
def makeleaf(n):
    return (n,[])
def maketree(parent,son):
    return (parent,son)
def subtree(lst):
	(p,s)=lst
	return s
def search(alpha,lst):
	for i in lst:
          if(i[0]==alpha):
	    return i
        return False
def suffixtree(words):
      tree=[]
      for word in words:
      	'''i = len(word)
      	word.reverse()
      	tr=makeleaf(word[0])
      	while(i>0):
        	tr=maketree(word[len(word)-i],tr)
        	i = i-1
	'''
	lst=tree
	tup=()
	for w in word:
	  if(search(w,lst)==False):
            tup=makeleaf(w)
	    lst.append(tup)	
	  else:
            tup=search(w,lst)	  
	  lst=subtree(tup)	
      return tree

class Dictionary:
  def __init__(self, fileName):
    self.words = []
    fin = open(fileName, 'r')
    while(True):
      line = fin.readline()
      if(line == ''):
        break
      else:
        self.words.append(string.strip(line))
    self.tree=suffixtree(self.words)
	
  def __str__(self):
    s = ""
    for w in self.words:
      s += w + "\n"
    return s
  
  def findPrefix(self, w):
	lst=self.tree
	for i in w:
		if(search(i,lst)==False):
			return False
		lst=subtree(search(i,lst))
	return True

if __name__ == "__main__":
  dictionary = Dictionary("new.txt")
  print dictionary.tree
  #print dictionary

  def t1():
    print dictionary.findPrefix("Zur")
    print dictionary.findPrefix("zbcd")

  #t1()
