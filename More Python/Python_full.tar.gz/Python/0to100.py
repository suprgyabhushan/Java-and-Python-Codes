n  = input("Enter a number: ")
while(n < 0 or n > 100):
    n = input("Enter another number: ")
if (n>=0 and n<=100):
    print "Entered number is in the range of 0 to 100"
