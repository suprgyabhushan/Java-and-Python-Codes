'''
def makeChange(Q,D):
	D.sort()
	D.reverse()
	ans=[]
	for i in D:
		ans.append(i)
		total = 0
		for x in ans:
			total = total + i
		if(total==Q):
			break
		if(total>Q):  
			ans.pop()
		else:
			makeChange(Q,D)
print makeChange(10,[1,2,3])
'''
def Change(Q,D,ans):
    for x in D:
        ans.append(x)
        tot = 0
        for y in ans:
            tot = tot + y
        if (tot == Q):
            break
        elif (tot > Q):
            ans.pop()
        else:
            Change(Q,D,ans)
    return ans
def makeChange(Q,D):
	ans=[]
	Change(Q,D,ans)
print makeChange(10,[3,2,1])
