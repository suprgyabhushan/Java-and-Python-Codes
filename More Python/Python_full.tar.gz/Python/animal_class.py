class Animal:
	def __init__(self,animal):
		self.animal = animal
	@property
	def speak(self):
		if(self.animal=="tiger"):
			return "oooooooooooooohhhhhhhhhhhhhhhhhhhtiger"
		if(self.animal=="lion"):
			return "ooooooooooooooooowwwwwwwwwwwlion"
if __name__ == "__main__":
	r = Animal("lion")
	print r.speak 
	#print type(Animal)
