class Rectangle:
	def __init__(self,l,b):

