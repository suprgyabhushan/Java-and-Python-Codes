class rectangle:
	def __init__(self,l,b): #constructor of the class in which it is being defined #when a function is surrounded by __ it means that it is                                             a special function(by convention in Python)
		self.l=l
		self.b=b
	def area(self):
		return (self.l*self.b)
	def perimeter(self):
		return (2*(self.l+self.b))
if __name__=="__main__":
	z=rectangle(10,8)
	ar=z.area()
	peri=z.perimeter()
	print ar
	print peri
