class person:
	def __init__(self,name,age):
		self.name=name
		self.age=age
	def store_name(self):
		return self.name
	def store_age(self):
		return self.age
if __name__=="__main__":
	send=person("NIKUNJ",18)
	#n=send.store_name()
	#a=send.store_age()
	print send.store_name()
	print send.store_age()
