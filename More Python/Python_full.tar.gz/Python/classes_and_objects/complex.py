class complex():
	def __init__(self,r1,i1,r2,i2):
		self.r1 = r1
		self.r2 = r2
		self.i1 = i1
		self.i2 = i2
	def add(self):
		#return str(self.r1+self.r2) + ' + i' + str(self.i1+self.i2)
		return ((self.r1+self.r2),(self.i1+self.i2))
	def subtract(self):
		return ((self.r1-self.r2),(self.i1-self.i2))
	def multiply(self):
		return (((self.r1*self.r2)-(self.i1*self.i2)),((self.r1*self.i2)+(self.r2*self.i1)))
	def divide(self):
		return ((((self.r1*self.r2)+(self.i1*self.i2))/((self.r2**2)+(self.i2**2))),((self.r2*self.i1)-(self.r1*self.i2))/((self.r2**2)+(self.i2**2)))
	def neg(self):
		return (-self.r1,-self.i1)
	def __str__(self):
		return str(self.add())
		#return str(self.r1) + " + i" + str(self.i1)
p = complex(1,2,3,4)
p1 = p.add()
p2 = p.subtract()
p3 = p.multiply()
p4 = p.divide()
p5 = p.neg()
print p1
print p2
print p3
print p4
print p5
print p
