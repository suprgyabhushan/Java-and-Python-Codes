class point:
	def __init__(self,a,b,c,d):
		self.a = a
		self.b = b
		self.c = c
		self.d = d
	def sum1(self):
		return self.a+self.b
	def sum2(self):
		return self.c+self.d
	def sum3(self):
		return self.sum1() + self.sum2()
	def __str__(self):
		return "Final Sum: " + str(self.sum3())
if __name__=="__main__":
	p = point(1,2,3,4)
	print p
