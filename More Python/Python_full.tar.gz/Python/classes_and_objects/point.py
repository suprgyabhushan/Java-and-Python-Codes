class Point(object):
	''' Represents a point in 2-D space ''' 
blank = Point()
print blank
