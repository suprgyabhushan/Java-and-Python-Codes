def add(p1, p2):
	return (p1[0]+p2[0],p1[1]+p2[1])
p1=(2,3)
p2=(8,7)
p3=add(p1,p2)
print p3

def getx: return p[0]
def gety: return p[1]

def makePoint(x,y): return (x,y)
def add(p1, p2):
	return (getx(p1)+getx(p2),gety(p1)+gety(p2))
def subtract(p1,p2):
	return (getx(p1)-getx(p2),gety(p1)-gety(p2))
