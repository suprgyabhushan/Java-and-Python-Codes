n = input("Enter a number: ")
if(n%2==0 and n%3==0):
    print "The entered number is divisible by 6"
else:
    print "the entered number is NOT divisible by 6"
