def double(n):
    return (2 * n)
n = input("Enter the number: ")
print "Double is = %d " % (double(n))
