def double2(n):# formal parameter # function definition
    return 2 * n
for i in range(1,11):
    print "2 * " + str(i) + " = " + str(double2(i))# actual parameter # function call
