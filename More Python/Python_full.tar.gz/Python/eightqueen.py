def conflict(pos,i):
    if(i in pos):
        return True
MAX = 8 
def solve(pos):
    pos = []
    values = [0,1,2,3,4,5,6,7]
    for i in values:
        if (not conflict(pos,i)):
            pos.append(i);
        if len(pos)==MAX:
            return
        solve(pos)
    if(len(pos)==MAX):
        return
    pos.pop()
print solve(a)
