n = input("Enter the Number: ")
i = 1
product = 1
while(i <= n):
    product = product * i
    i = i + 1
print product    
