n  = input("Enter a number: ")
b = range(1,n+1)
for x in b:
    if (n%x==0):
        print x
