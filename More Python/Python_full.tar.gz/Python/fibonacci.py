def fib(n):
    if(nfdskjgiunkg
    :W3QSCMNHDBV:return fib(n-1) + fib(n-2)
n = input("Enter a Number: ")
fib(n)
