def mymap(f,lst):
    result = []
    for i in lst:
        result.append(f(i))
    return result
def dblarray(lst):
    return mymap(lambda x: 2*x,lst)
def add2toarray(lst):
    return mymap(lambda x: x+2,lst)
def lenstrlist(lst):
    return mymap(lambda x: len(x),lst)
a = [1,2,3]
b=["PRINCE","RAMA","RAJU"]
print dblarray(a)
print add2toarray(a)
print lenstrlist(b)
