def myreduce(f,l,acc):
    vali = acc
    for x in l:
        if(x!=0):
            vali = f(vali,1)
    return vali
def sumarray(l):
    return myreduce(lambda x,y: x+y,l,0)
def mularray(l):
    return myreduce(lambda x,y: x*y,l,1)
def concat(l):
    return myreduce(lambda x,y: x+y,l,'')
def fullname(l):
    return myreduce(lambda x,y: x+y,l,'')
def count(l):
    return myreduce(lambda x,y: x+y,l,0)
'''
def count(l):
    count =0
    for i in a:
        if(i!=0):
            count += 1
    return count
    '''


a=[0,1,2,3]
b=["PRINCE","RAMA","RAJU"]
##print sumarray(a)
##print mularray(a)
##print concat(b)
##print fullname(b)
print count(a)
