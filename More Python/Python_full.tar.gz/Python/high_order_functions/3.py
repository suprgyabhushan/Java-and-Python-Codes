'''def myfilter(f,l):
    result = []
    for i in l:
        result.append(f(i))
    return result'''
def odd(l):
    return filter(lambda x: x%2==1,l)
def even(l):
    return filter(lambda x: x%2==0,l)
def ing(l):
    return filter(lambda x: x[len(x)-3:len(x)]=="ING",l)
a = [1,2,3]
b = ["PRINCE","RAMA","RAJU","ING","SCREAMING"]
print odd(a)
print even(a)
print ing(b)
