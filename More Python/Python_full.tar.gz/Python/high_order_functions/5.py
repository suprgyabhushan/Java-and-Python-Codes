def f(x):
    def g(y):
        return x*y
    return g
mul10=f(10)
mul5=f(5)
print mul5(5)
print mul10(5)
