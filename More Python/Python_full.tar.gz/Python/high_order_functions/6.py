def even(l): return filter(lambda x: x%2==0,l)
def odd(l): return filter(lambda x: x%2==1,l)
def greatereven(l): 
	if(sum(even(l))>sum(odd(l))): 
		return True
	else:
		return False
a = [1,3,5,7,2,2];
print greatereven(a)
