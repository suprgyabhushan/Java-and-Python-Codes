y=2000
if ((y%100)==0):
	if((y%400)==0):
		print True
	else:
		print False
else:
	if((y%4)==0):
		print True
	else:
		print False


