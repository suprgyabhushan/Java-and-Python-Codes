n = input("Enter the number: ")
a = list('n')
b = a.reverse()
if(b.join(a) == n):
    print True
else:
    print False
