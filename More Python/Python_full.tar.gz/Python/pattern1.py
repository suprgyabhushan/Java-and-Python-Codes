n = input("Enter a number: ")
i = 1
while(i<=n):
    j = 1
    while(j<=i):
       print j
       j += 1
    i = i + 1

