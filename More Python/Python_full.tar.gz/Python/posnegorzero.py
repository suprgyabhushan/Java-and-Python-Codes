n = input ("Enter a number : ")
if(n<0):
    print "Negative"
else:
    if(n>0):
        print "Positive"
    else:
        print "zero"
