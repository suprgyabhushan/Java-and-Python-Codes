c=raw_input("Enter a character: ")
if(c=='a' or c=='e' or c=='i' or c=='o' or c=='u'):
    print "Vowel"
else:
    print "Consonant"
