n = input("Enter a number: ")
a = list(str(n))
sums = 0
for i in a:
    sums = sums + int (i)
print sums
