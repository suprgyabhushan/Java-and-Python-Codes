limit = input("Enter Limit: ")
i=1
print "0"
print "0"
a = 0
b = 1
while(i<=limit):
    c = a + b
    print c
    a = b
    b = c
    i = i + 1
