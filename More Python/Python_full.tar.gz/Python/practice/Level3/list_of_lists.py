length = input("Enter a length: ")
i = 1
a=[]
while(i<=length):
    n= input("Enter list: ")
    a.append(n)
    i = i + 1
print a
