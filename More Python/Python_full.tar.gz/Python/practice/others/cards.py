import string
class Cards():
	def __init__(self,suit,rank):
		self.rank = rank
		self.suit = suit
	suit_names = ["Spades","Hearts","Diamonds","Clubs"]
	rank_names = [None,"Ace","2","3","4","5","6","7","8","9","10","Jack","Queen","King"]
	def compare(self,other):
		a = self.rank,self.suit
		b = other.rank,other.suit
		return cmp(a,b)	
	def __str__(self):
		return '%s of %s' % (Cards.rank_names[self.rank],Cards.suit_names[self.suit])
class Deck():
	def __init__(self):
		self.cards = []
		for suit in range(4):
			for rank in range(14):
				card = Cards(suit,rank)
				self.cards.append(card)
	def __str__(self):
		copydeck = []
		for card in self.cards:
			copydeck.append(str(card))
		return '\n'.join(copydeck)
deck = Deck()
print deck

		


if __name__ == "__main__":
    cards = Cards(1,12)
    cards1 = Cards(1,12)
    #print cards.compare(cards1)
    #print cards
