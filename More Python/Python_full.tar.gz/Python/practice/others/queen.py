def solve(pos):
    value = [0,1,2,3]
    max = len(value)
    for i in range(max):
        if(not conflict(pos,i)):
            pos.append(i)
        if(len(pos)==max):
            return pos
        solve(pos,i)
        if(len(pos)==max):
            return pos
        pos.pop()
def conflict(pos,i):
    if(i in pos):
        return True
    else











if __name__=="__main__":    
