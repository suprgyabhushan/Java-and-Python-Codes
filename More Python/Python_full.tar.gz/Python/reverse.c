n=input("Enter the number to be reversed: ")

