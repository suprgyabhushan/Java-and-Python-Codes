n = input("enter the number: ")
i = 0
sum  = 0
while(i <= n):
    sum = sum + i
    i += 1
print sum    
