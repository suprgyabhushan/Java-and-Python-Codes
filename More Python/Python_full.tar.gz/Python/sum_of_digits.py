n = input("enter a number")

