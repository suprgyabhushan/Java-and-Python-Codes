def makeLeaf(n):
	return (n,[])
def makeTree(n,children):
	return (n,children)


##Test Cases Checking
l1 = makeLeaf(1)
l2 = makeLeaf(2)
l3 = makeLeaf(3)
l4 = makeLeaf(4)
l5 = makeLeaf(5)
l6 = makeLeaf(6)

tree1 = makeTree(4, [l1, l2, l3])
tree2 = makeTree(3, [l1, l2, l3])

n7 = makeTree(7, [l1, l2, l3])
n8 = makeTree(8, [l4, l5, l6])
tree3 = makeTree(9, [n7, n8])
def test_makeTree():
  print "**** makeTree - begin ****"
  def t1():
    print "-- t1 - begin"
    print "tree = " + str(tree1)
    print "-- t1 - end"

  def t2():
    print "-- t2 - begin"

    print "tree = " + str(tree2)
    print "-- t2 - end"

  def t3():
    print "-- t3 - begin"
    print "tree = " + str(tree3)
    print "-- t3 - end"


  t1()
  t2()
  t3()
  print "**** makeTree - end ****"

test_makeTree()
