def abc(lst):
    s = ""
    for w in lst:
        s += w + "\n"
    return s
lst=['tree','suffix']
print abc(lst)
